Huffman Algorithm
